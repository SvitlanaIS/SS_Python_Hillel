from groupLimitException import GroupLimitException

class Group:

    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student):
        if len(self.group) < 10:
            self.group.add(student)
            print(f"Студент {student.last_name} доданий до групи {self.number}")
        else:
             raise GroupLimitException()

    def delete_student(self, last_name):
        student = self.find_student(last_name)
        if student:
            self.group.remove(student)
            print(f"Студент {last_name} видалений із групи {self.number}")
        else:
            print(f"Студент {last_name} не знайдено у групі {self.number}")

    def find_student(self, last_name):
        return next((student for student in self.group if student.last_name == last_name), None)

    def __str__(self):
        all_students = "\n".join(str(student) for student in self.group)
        return f'Number: {self.number}\n{all_students}'