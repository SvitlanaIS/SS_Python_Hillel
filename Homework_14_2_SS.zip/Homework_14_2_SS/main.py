from student import Student
from group import Group


def main():
    st1 = Student('Male', 30, 'Steve', 'Jobs', 'AN142')
    st2 = Student('Female', 25, 'Liza', 'Taylor', 'AN145')
    st3 = Student('Male', 31, 'Oliver', 'Smith', 'AN146')
    st4 = Student('Female', 26, 'Olivia', 'Johnson', 'AN148')
    st5 = Student('Male', 33, 'Harry:', 'Williams', 'AN149')
    st6 = Student('Female', 28, 'Emily', 'Jones', 'AN141')
    st7 = Student('Male', 35, 'Charlie', 'Brown', 'AN143')
    st8 = Student('Female', 29, 'Isabella', 'Davis', 'AN147')
    st9 = Student('Male', 36, 'Thomas', 'Miller', 'AN144')
    st10 = Student('Female', 27, 'Charlotte', 'Wilson', 'AN140')
    st11 = Student('Female', 25, 'Abigail', 'Davies', 'AN150')

    gr = Group('PD1')

    try:
        gr.add_student(st1)
        gr.add_student(st2)
        gr.add_student(st3)
        gr.add_student(st4)
        gr.add_student(st5)
        gr.add_student(st6)
        gr.add_student(st7)
        gr.add_student(st8)
        gr.add_student(st9)
        gr.add_student(st10)
        gr.add_student(st11)

    except Exception as e:
        print(f"Error: {e}")

    print(gr)

    assert gr.find_student('Jobs') == st1
    assert gr.find_student('Jobs2') is None

    gr.delete_student('Taylor')
    print(gr)  # Only one student

    gr.delete_student('Taylor')  # No error!

if __name__ == '__main__':
    main()
