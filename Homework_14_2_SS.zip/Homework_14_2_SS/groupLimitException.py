class GroupLimitException(Exception):
    def __init__(self, message="Неможливо додати більше 10 студентів до групи."):
        self.message = message
        super().__init__(self.message)